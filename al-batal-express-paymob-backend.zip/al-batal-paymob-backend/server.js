const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const admin = require('firebase-admin');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const API_URL = (process.env.PAYMOB_API_URL || 'https://accept.paymob.com/api').replace(/\/$/, '');
const PLANS = {
  2: { captainsCount: 2, price: 400, plan: '2 Captains' },
  4: { captainsCount: 4, price: 600, plan: '4 Captains' },
  6: { captainsCount: 6, price: 800, plan: '6 Captains' },
  8: { captainsCount: 8, price: 1000, plan: '8 Captains' },
};

// Firebase Admin credentials are supplied ONLY through Render environment variables.
function initFirebase() {
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is missing');
  const serviceAccount = JSON.parse(raw);
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: process.env.FIREBASE_PROJECT_ID || serviceAccount.project_id,
  });
}
initFirebase();
const db = admin.firestore();

// Paymob HMAC must be calculated from the exact documented field order.
function paymobHmacData(obj) {
  const values = [
    obj.amount_cents, obj.created_at, obj.currency, obj.error_occured,
    obj.has_parent_transaction, obj.id, obj.integration_id, obj.is_3d_secure,
    obj.is_auth, obj.is_capture, obj.is_refunded, obj.is_standalone_payment,
    obj.is_voided, obj.order?.id, obj.owner, obj.pending,
    obj.source_data?.pan, obj.source_data?.sub_type, obj.source_data?.type,
    obj.success,
  ];
  return values.map(v => String(v ?? '')).join('');
}
function validHmac(obj, received) {
  const secret = process.env.PAYMOB_HMAC_SECRET;
  if (!secret || !received) return false;
  const expected = crypto.createHmac('sha512', secret).update(paymobHmacData(obj)).digest('hex');
  const a = Buffer.from(expected.toLowerCase(), 'utf8');
  const b = Buffer.from(String(received).toLowerCase(), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
async function requireFirebaseUser(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const match = header.match(/^Bearer\s+(.+)$/i);
    if (!match) return res.status(401).json({ success: false, error: 'Missing Firebase ID token' });
    req.firebaseUser = await admin.auth().verifyIdToken(match[1], true);
    next();
  } catch (e) {
    return res.status(401).json({ success: false, error: 'Invalid or expired Firebase ID token' });
  }
}
async function getOwnedRestaurant(uid, restaurantId, claims) {
  if (!restaurantId) throw new Error('restaurantId is required');
  const snap = await db.collection('restaurants').doc(restaurantId).get();
  if (!snap.exists) throw new Error('Restaurant not found');
  const data = snap.data();
  const authorized = restaurantId === uid || claims.restaurantId === restaurantId || data.ownerUid === uid;
  if (!authorized) throw new Error('This account does not own the selected restaurant');
  return { id: snap.id, data };
}
function safeName(value, fallback) {
  const s = String(value || '').trim();
  return s ? s.slice(0, 80) : fallback;
}

app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean),
  credentials: false,
}));
// Keep raw body available if needed for future Paymob signature variants.
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.json({ success: true, service: 'al-batal-paymob-backend' }));

// Client sends plan choice only. Price is always resolved on the server.
app.post('/api/payments/create', requireFirebaseUser, async (req, res) => {
  try {
    const { restaurantId, captainsCount, paymentMethod = 'card', phoneNumber } = req.body || {};
    const plan = PLANS[Number(captainsCount)];
    if (!plan) return res.status(400).json({ success: false, error: 'Invalid subscription plan' });
    if (!['card', 'wallet'].includes(paymentMethod)) return res.status(400).json({ success: false, error: 'Unsupported payment method' });
    if (paymentMethod === 'wallet' && !/^\+?20?1[0125][0-9]{8}$/.test(String(phoneNumber || '').replace(/[\s-]/g, ''))) {
      return res.status(400).json({ success: false, error: 'A valid Egyptian wallet phone number is required' });
    }
    const restaurant = await getOwnedRestaurant(req.firebaseUser.uid, restaurantId, req.firebaseUser);
    const apiKey = process.env.PAYMOB_API_KEY;
    const integrationId = paymentMethod === 'wallet' ? process.env.PAYMOB_WALLET_INTEGRATION_ID : process.env.PAYMOB_CARD_INTEGRATION_ID;
    if (!apiKey || !integrationId || (paymentMethod === 'card' && !process.env.PAYMOB_IFRAME_ID)) {
      return res.status(503).json({ success: false, error: 'Paymob credentials are not fully configured' });
    }
    const paymentRef = db.collection('payments').doc();
    const merchantOrderId = `batal_${paymentRef.id}`;
    const amountCents = plan.price * 100;
    const email = req.firebaseUser.email || restaurant.data.email || 'customer@example.com';
    const displayName = safeName(restaurant.data.name || restaurant.data.nameAr, 'Merchant');
    const names = displayName.split(/\s+/);
    const auth = await axios.post(`${API_URL}/auth/tokens`, { api_key: apiKey }, { timeout: 20000 });
    const order = await axios.post(`${API_URL}/ecommerce/orders`, {
      auth_token: auth.data.token, delivery_needed: false, amount_cents: amountCents,
      currency: 'EGP', merchant_order_id: merchantOrderId, items: [],
    }, { timeout: 20000 });
    const paymentKey = await axios.post(`${API_URL}/acceptance/payment_keys`, {
      auth_token: auth.data.token, amount_cents: amountCents, expiration: 3600,
      order_id: order.data.id, currency: 'EGP', integration_id: Number(integrationId),
      lock_order_when_paid: true,
      billing_data: {
        apartment: 'NA', email, floor: 'NA', first_name: names[0] || 'Merchant',
        street: 'NA', building: 'NA', phone_number: phoneNumber || restaurant.data.phone || '01000000000',
        shipping_method: 'NA', postal_code: 'NA', city: 'Cairo', country: 'EG',
        last_name: names.slice(1).join(' ') || 'Merchant', state: 'NA',
      },
    }, { timeout: 20000 });

    await paymentRef.set({
      restaurantId, restaurantName: displayName, amount: plan.price, amountCents,
      currency: 'EGP', paymentMethod: paymentMethod === 'wallet' ? 'Mobile Wallet' : 'Visa',
      method: paymentMethod, status: 'pending', plan: plan.plan,
      integrationId: String(integrationId), captainsCount: plan.captainsCount, paymobOrderId: String(order.data.id),
      merchantOrderId, createdAt: admin.firestore.FieldValue.serverTimestamp(),
      firebaseUid: req.firebaseUser.uid,
    });
    let paymentUrl;
    if (paymentMethod === 'wallet') {
      const wallet = await axios.post(`${API_URL}/acceptance/payments/pay`, {
        source: { identifier: String(phoneNumber).replace(/[\s-]/g, ''), subtype: 'WALLET' },
        payment_token: paymentKey.data.token,
      }, { timeout: 20000 });
      paymentUrl = wallet.data.iframe_redirection_url;
    } else {
      paymentUrl = `https://accept.paymob.com/api/acceptance/iframes/${process.env.PAYMOB_IFRAME_ID}?payment_token=${paymentKey.data.token}`;
    }
    if (!paymentUrl) throw new Error('Paymob did not return a payment URL');
    await paymentRef.update({ paymentUrl });
    return res.status(200).json({ success: true, paymentId: paymentRef.id, paymentUrl, amount: plan.price, currency: 'EGP' });
  } catch (error) {
    console.error('Create payment failed:', error.response?.data || error.message);
    return res.status(400).json({ success: false, error: error.message || 'Unable to create payment' });
  }
});

// Paymob transaction callback: only a valid HMAC + matching pending payment can activate a plan.
app.all('/api/payments/webhook', async (req, res) => {
  try {
    const obj = req.method === 'GET' ? req.query : req.body?.obj;
    const hmac = req.query.hmac || req.body?.hmac;
    if (!obj || !validHmac(obj, hmac)) return res.status(401).send('Invalid HMAC');
    const orderId = String(obj.order?.id || '');
    const txnId = String(obj.id || '');
    if (!orderId || !txnId) return res.status(400).send('Missing transaction identifiers');
    const q = await db.collection('payments').where('paymobOrderId', '==', orderId).limit(1).get();
    if (q.empty) return res.status(404).send('Payment record not found');
    const paymentDoc = q.docs[0];
    const payment = paymentDoc.data();
    const paidAmount = Number(obj.amount_cents);
    const isSuccess = obj.success === true && obj.pending === false && obj.error_occured === false;
    if (paidAmount !== Number(payment.amountCents)) return res.status(400).send('Amount mismatch');
    if (String(obj.integration_id) !== String(payment.integrationId)) return res.status(400).send('Integration mismatch');

    const txnRef = db.collection('paymob_transactions').doc(txnId);
    await db.runTransaction(async tx => {
      const [txnSnap, freshPaymentSnap] = await Promise.all([tx.get(txnRef), tx.get(paymentDoc.ref)]);
      if (txnSnap.exists) return; // Idempotent webhook retry.
      const fresh = freshPaymentSnap.data();
      if (!fresh) throw new Error('Payment record disappeared');
      tx.create(txnRef, { transactionId: txnId, paymentId: paymentDoc.id, orderId, success: isSuccess, amountCents: paidAmount, createdAt: admin.firestore.FieldValue.serverTimestamp() });
      if (fresh.status !== 'pending') return;
      if (!isSuccess) {
        tx.update(paymentDoc.ref, { status: 'failed', transactionId: txnId, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        return;
      }
      const now = new Date();
      const end = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      const fmt = d => d.toISOString().slice(0, 10);
      const subscriptionRef = db.collection('subscriptions').doc(`sub_${paymentDoc.id}`);
      tx.set(subscriptionRef, {
        restaurantId: fresh.restaurantId, restaurantName: fresh.restaurantName,
        plan: fresh.plan, captainsCount: fresh.captainsCount, price: fresh.amount,
        startDate: fmt(now), endDate: fmt(end), status: 'Active',
        paymentId: paymentDoc.id, transactionId: txnId,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      tx.update(paymentDoc.ref, {
        status: 'success', transactionId: txnId, transactionNumber: txnId,
        date: fmt(now), paidAt: admin.firestore.FieldValue.serverTimestamp(),
        subscriptionId: subscriptionRef.id, updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      tx.set(db.collection('restaurants').doc(fresh.restaurantId), {
        subscriptionStatus: 'Active', subscriptionId: subscriptionRef.id,
        subscriptionEndDate: fmt(end), captainsLimit: fresh.captainsCount,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    });
    return res.status(200).send('OK');
  } catch (error) {
    console.error('Webhook processing failed:', error.message);
    return res.status(500).send('Webhook processing failed');
  }
});

app.get('/api/payments/return', (_req, res) => res.status(200).send('<main style="font-family:Arial;text-align:center;margin:4rem"><h2>تم استلام نتيجة الدفع</h2><p>يرجى العودة إلى تطبيق البطل إكسبريس. يتم تحديث الاشتراك بعد التحقق من إشعار Paymob.</p></main>'));

app.listen(PORT, () => console.log(`Al-Batal Paymob backend listening on ${PORT}`));
