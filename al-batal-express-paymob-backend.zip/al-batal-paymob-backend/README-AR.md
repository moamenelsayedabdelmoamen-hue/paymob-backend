# ربط Paymob مع البطل إكسبريس وFirestore الحالية

## ما الذي يفعله هذا الخادم؟
- يتحقق من Firebase ID Token لكل طلب إنشاء دفع.
- يتحقق أن المستخدم مالك المطعم (`restaurants/{restaurantId}.ownerUid`) أو أن `restaurantId` يطابق UID/Custom Claim.
- لا يقبل السعر من التطبيق؛ السعر محدد على الخادم: 2 كابتن=400، 4=600، 6=800، 8=1000 جنيه.
- ينشئ سجل `payments` بحالة `pending` ثم يرسل العميل إلى Paymob.
- لا يفعّل الاشتراك إلا بعد HMAC صحيح، وتطابق رقم الطلب والمبلغ، ومعالجة آمنة قابلة لإعادة المحاولة.
- يكتب في `payments` و`subscriptions` ويحدّث `restaurants` داخل Firestore نفسها.

## قبل النشر - مهم جداً
1. المفتاح السري الذي كان مكتوباً داخل النسخة القديمة من `server.js` يجب إلغاؤه/تدويره فوراً من لوحة Paymob. لا تعِد استخدامه.
2. لا تضع ملف Service Account في GitHub أو داخل تطبيق التاجر/الكابتن. ضعه كمتغير سري في Render فقط.
3. استخرج من Firebase Console > Project settings > Service accounts مفتاح JSON جديداً، ثم انسخ محتواه كاملاً إلى متغير Render `FIREBASE_SERVICE_ACCOUNT_JSON`.
4. من Paymob انسخ API Key وHMAC Secret وCard Integration ID وWallet Integration ID وIframe ID إلى Render. لا ترسلها في المحادثة.
5. اجعل `ALLOWED_ORIGINS` نطاقات الويب الفعلية مفصولة بفواصل.

## نشر Render
- ارفع مجلد هذا المشروع إلى مستودع GitHub جديد/خاص بعد التأكد من عدم وجود أسرار.
- Render > New > Web Service > اربط المستودع.
- Runtime Node، Build Command `npm install`، Start Command `npm start`.
- أضف متغيرات البيئة المذكورة أعلاه. `FIREBASE_PROJECT_ID` = `el-batal-express-956ae`.
- بعد النشر اختبر `https://YOUR-SERVICE.onrender.com/health` ويجب أن يعيد `{"success":true,...}`.
- عيّن Paymob Transaction Processed Callback/Webhook إلى `https://YOUR-SERVICE.onrender.com/api/payments/webhook`. فعّل HMAC من إعدادات Paymob.
- Return URL (إن كان مطلوباً) هو `https://YOUR-SERVICE.onrender.com/api/payments/return`. لا تعتمد على Return URL لتفعيل الاشتراك.

## API الذي يستدعيه تطبيق التاجر
`POST /api/payments/create`
Headers: `Authorization: Bearer <Firebase ID Token>` و`Content-Type: application/json`
Body مثال: `{"restaurantId":"RESTAURANT_DOC_ID","captainsCount":4,"paymentMethod":"card"}`
للمحفظة: أضف `"paymentMethod":"wallet","phoneNumber":"01012345678"`.
الاستجابة تتضمن `paymentUrl` و`paymentId` و`amount`. افتح `paymentUrl` داخل WebView/المتصفح المناسب.

## ملاحظات دمج ضرورية
- يجب أن يرسل تطبيق التاجر `restaurantId` الحقيقي وFirebase ID Token الحالي، وليس رقم/اسم يختاره المستخدم.
- تحقق من أن حساب التاجر لديه `ownerUid` في مستند المطعم أو Custom Claim `restaurantId`. هذا متوافق مع دالة `isRestaurant` الموجودة في قواعد Firestore المرفقة.
- نسخة لوحة التحكم الحالية تحتوي اختلافاً بين تعريف الباقات في `collections.ts` (400/600/800/1000) وبين نموذج صفحة الاشتراكات (400/700/1000). هذا الخادم يتبع تعريف `collections.ts` المطلوب (2/4/6/8 كباتن). وحّد واجهة عرض الباقات قبل الإطلاق.
- يجب إزالة أي تفعيل اشتراك تلقائي من الواجهة بعد رجوع المستخدم من صفحة الدفع. الحالة الموثوقة تأتي من Firestore بعد webhook فقط.
- Admin SDK يتجاوز Firestore Rules؛ لذلك التحقق من هوية مالك المطعم موجود داخل الخادم.
- اختبر أولاً بمفاتيح/بيئة Paymob التجريبية، ثم نفّذ دفعة فعلية صغيرة قبل فتح الخدمة للجميع.
